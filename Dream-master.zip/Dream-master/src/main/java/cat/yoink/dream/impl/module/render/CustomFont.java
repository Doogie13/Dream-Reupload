package cat.yoink.dream.impl.module.render;

import cat.yoink.dream.api.module.Category;
import cat.yoink.dream.api.module.Module;

/**
 * @author yoink
 * @since 9/20/2020
 */
public class CustomFont extends Module
{
	public CustomFont(String name, String description, Category category)
	{
		super(name, description, category);
	}
}
