package cat.yoink.dream.mixin.mixins.accessor;

/**
 * @author yoink
 * @since 9/20/2020
 */
public interface ITimer
{
	float getTickLength();
	void setTickLength(float length);
}
