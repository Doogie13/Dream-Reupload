package cat.yoink.dream.impl.module.component;

import cat.yoink.dream.api.module.Category;
import cat.yoink.dream.api.module.Module;

public class Watermark extends Module
{
    public Watermark(String name, Category category)
    {
        super(name, category);
    }
}
