package cat.yoink.dream.api.setting;

/**
 * @author yoink
 * @since 9/20/2020
 */
public enum SettingType
{
	BOOLEAN,
	INTEGER,
	ENUM
}
